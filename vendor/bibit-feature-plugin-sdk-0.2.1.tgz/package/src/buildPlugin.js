import { createHash, generateKeyPairSync, sign } from 'node:crypto'
import {
  chmod,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rm,
  writeFile,
} from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, relative, resolve } from 'node:path'
import { createRequire } from 'node:module'
import Ajv from 'ajv'
import * as tar from 'tar'
import { build } from 'vite'

const require = createRequire(import.meta.url)
const schema = JSON.parse(
  await readFile(
    require.resolve(
      '@bibit/feature-contracts/schema/bibit-feature.schema.json'
    ),
    'utf8'
  )
)
const validateManifest = new Ajv({ allErrors: true }).compile(schema)

const readJson = async (path) => JSON.parse(await readFile(path, 'utf8'))

const listFiles = async (root) => {
  const files = []
  const visit = async (directory) => {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name)
      if (entry.isDirectory()) await visit(path)
      else if (entry.isFile()) files.push(path)
    }
  }
  await visit(root)
  return files.sort()
}

export async function generatePluginSigningKey({ outputDir, keyId }) {
  if (!/^[a-z0-9][a-z0-9._-]{1,63}$/.test(keyId)) {
    throw new Error('keyId must be a 2-64 character lowercase identifier')
  }
  const { privateKey, publicKey } = generateKeyPairSync('ed25519')
  const privateKeyPath = join(outputDir, `${keyId}-private.pem`)
  const trustEntryPath = join(outputDir, `${keyId}-public.json`)
  const trustStorePath = join(outputDir, `${keyId}-trust-store.json`)
  const publicJwk = publicKey.export({ format: 'jwk' })
  const trustEntry = {
    keyId,
    publicKey: Buffer.from(publicJwk.x, 'base64url').toString('base64'),
  }
  await mkdir(outputDir, { recursive: true })
  await writeFile(
    privateKeyPath,
    privateKey.export({ type: 'pkcs8', format: 'pem' }),
    { mode: 0o600 }
  )
  await chmod(privateKeyPath, 0o600)
  await writeFile(
    trustEntryPath,
    `${JSON.stringify(
      trustEntry,
      null,
      2
    )}\n`
  )
  await writeFile(
    trustStorePath,
    `${JSON.stringify({ version: 1, keys: [trustEntry] }, null, 2)}\n`
  )
  return { privateKeyPath, trustEntryPath, trustStorePath }
}

export async function buildPluginBundle({ cwd, privateKeyPath, keyId }) {
  const packageJson = await readJson(join(cwd, 'package.json'))
  const config = packageJson.bibitPlugin
  if (!config || typeof config.entry !== 'string' || typeof config.manifest !== 'string') {
    throw new Error('package.json must define bibitPlugin.entry and bibitPlugin.manifest')
  }
  const featureManifest = await readJson(resolve(cwd, config.manifest))
  if (!validateManifest(featureManifest)) {
    const firstError = validateManifest.errors?.[0]
    throw new Error(
      `Feature Manifest is invalid: ${firstError?.instancePath || '/'} ${firstError?.message || ''}`
    )
  }
  const stagingRoot = await mkdtemp(join(tmpdir(), 'bibit-plugin-'))
  const distRoot = join(stagingRoot, 'dist')
  try {
    await build({
      configFile: false,
      root: cwd,
      logLevel: 'warn',
      define: {
        'process.env.NODE_ENV': JSON.stringify('production'),
      },
      build: {
        emptyOutDir: true,
        outDir: distRoot,
        cssCodeSplit: false,
        lib: {
          entry: resolve(cwd, config.entry),
          formats: ['es'],
          fileName: () => 'plugin.js',
        },
        rollupOptions: { output: { inlineDynamicImports: true } },
      },
    })
    const files = {}
    for (const path of await listFiles(distRoot)) {
      const name = `dist/${relative(distRoot, path).replaceAll('\\', '/')}`
      files[name] = createHash('sha256')
        .update(await readFile(path))
        .digest('hex')
    }
    const styles = Object.keys(files).filter((path) => path.endsWith('.css'))
    const pluginManifest = {
      pluginSchemaVersion: 1,
      featureManifest,
      entry: 'dist/plugin.js',
      styles,
      files,
    }
    const manifestBytes = Buffer.from(`${JSON.stringify(pluginManifest, null, 2)}\n`)
    const privateKey = await readFile(privateKeyPath, 'utf8')
    const signature = sign(null, manifestBytes, privateKey).toString('base64')
    await writeFile(join(stagingRoot, 'plugin.json'), manifestBytes)
    await writeFile(
      join(stagingRoot, 'plugin.sig'),
      `${JSON.stringify({ keyId, signature }, null, 2)}\n`
    )
    const artifactDir = resolve(cwd, config.artifactDir ?? 'artifacts')
    const bundlePath = join(
      artifactDir,
      `${featureManifest.id}-${featureManifest.version}.bibit-plugin.tgz`
    )
    await mkdir(dirname(bundlePath), { recursive: true })
    await tar.c(
      {
        gzip: true,
        cwd: stagingRoot,
        file: bundlePath,
        portable: true,
        noMtime: true,
      },
      ['plugin.json', 'plugin.sig', 'dist']
    )
    return {
      bundlePath,
      manifest: pluginManifest,
      fileName: basename(bundlePath),
    }
  } finally {
    await rm(stagingRoot, { recursive: true, force: true })
  }
}
