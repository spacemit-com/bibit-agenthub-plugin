import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it } from 'vitest'
import type { FeatureManifestV1 } from '@bibit/feature-contracts'
import type { FeatureModuleV1 } from '@bibit/feature-sdk'
import { FeatureDevHost } from './FeatureDevHost'

const manifest: FeatureManifestV1 = {
  manifestSchemaVersion: 1,
  sdkApiVersion: 1,
  id: 'fixture',
  version: '0.1.0',
  owner: 'fixture-team',
  display: {
    titleKey: 'fixture:title',
    fallbackTitle: 'Fixture',
    iconKey: 'feature',
  },
  targets: ['desktop'],
  requiredHostCapabilities: [],
  contributions: {
    pages: [{ id: 'home', path: '', surfaces: ['main'] }],
    settings: [{ id: 'preferences', path: '', surfaces: ['main'] }],
    conversation: [],
    locales: ['en'],
  },
}

const module: FeatureModuleV1 = {
  sdkApiVersion: 1,
  pages: { home: () => <h2>Feature page</h2> },
  settings: { preferences: () => <h2>Feature settings</h2> },
}

describe('FeatureDevHost', () => {
  it('switches between declared contributions without Bibit', async () => {
    const user = userEvent.setup()
    render(<FeatureDevHost manifest={manifest} module={module} />)

    expect(screen.getByRole('heading', { name: 'Feature page' })).toBeTruthy()
    await user.click(screen.getByRole('button', { name: 'Settings · preferences' }))
    expect(screen.getByRole('heading', { name: 'Feature settings' })).toBeTruthy()
    expect(screen.getByText('SDK 1')).toBeTruthy()
  })
})
