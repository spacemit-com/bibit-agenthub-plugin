export const FEATURE_HOST_CAPABILITIES = [
  'external-service:store',
  'external-service:memory',
  'external-service:security',
  'runtime:permission',
] as const

export type FeatureHostCapability = (typeof FEATURE_HOST_CAPABILITIES)[number]

export const EXPERIMENTAL_FEATURE_HOST_CAPABILITIES = [
  'external-service:store',
  'external-service:memory',
  'external-service:security',
] as const satisfies readonly FeatureHostCapability[]
