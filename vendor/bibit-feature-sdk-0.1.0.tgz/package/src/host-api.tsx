import type { ReactNode } from 'react'
import { createContext, createElement, useContext } from 'react'
import type {
  FeatureHostCapability,
  FeatureManifestV1,
  FeatureServiceErrorV1,
} from '@bibit/feature-contracts'

export type FeatureExternalServiceIdV1 = 'store' | 'memory' | 'security'

export interface FeatureExternalServiceRequestV1<
  TServiceId extends FeatureExternalServiceIdV1,
> {
  serviceId: TServiceId
  operationId: string
  params: Readonly<Record<string, unknown>>
  timeoutMs?: number
  signal?: AbortSignal
}

export interface FeatureExternalServiceApiV1<
  TServiceId extends FeatureExternalServiceIdV1,
> {
  request<TResult = unknown>(
    input: FeatureExternalServiceRequestV1<TServiceId>
  ): Promise<TResult>
}

export type FeatureExternalServiceErrorV1 = FeatureServiceErrorV1

export interface FeatureHostCapabilityApisV1 {
  'external-service:store': FeatureExternalServiceApiV1<'store'>
  'external-service:memory': FeatureExternalServiceApiV1<'memory'>
  'external-service:security': FeatureExternalServiceApiV1<'security'>
}

export type FeatureHostCapabilityApiV1<K extends FeatureHostCapability> =
  K extends keyof FeatureHostCapabilityApisV1
    ? FeatureHostCapabilityApisV1[K]
    : unknown

export interface FeatureHostApiV1 {
  sdkApiVersion: 1
  featureId: FeatureManifestV1['id']
  grantedCapabilities: readonly FeatureHostCapability[]
  getCapability<K extends FeatureHostCapability>(
    capability: K
  ): FeatureHostCapabilityApiV1<K> | undefined
}

const FeatureHostApiContext = createContext<FeatureHostApiV1 | undefined>(
  undefined
)

export interface FeatureHostApiProviderProps {
  value: FeatureHostApiV1
  children?: ReactNode
}

export function FeatureHostApiProvider({
  value,
  children,
}: FeatureHostApiProviderProps) {
  return createElement(FeatureHostApiContext.Provider, { value }, children)
}

export function useFeatureHostApi(): FeatureHostApiV1 {
  const hostApi = useContext(FeatureHostApiContext)
  if (!hostApi) {
    throw new Error('useFeatureHostApi must be used within FeatureHostApiProvider')
  }
  return hostApi
}

export function useFeatureCapability<K extends FeatureHostCapability>(
  capability: K
): FeatureHostCapabilityApiV1<K> | undefined {
  return useFeatureHostApi().getCapability(capability)
}
