import Ajv from 'ajv'
import { describe, expect, it } from 'vitest'
import manifestSchema from '../schema/bibit-feature.schema.json'
import {
  FEATURE_HOST_CAPABILITIES,
  FEATURE_ICON_KEYS,
  FEATURE_PAGE_NAVIGATION_GROUPS,
  FEATURE_SETTINGS_NAVIGATION_GROUPS,
  validateFeatureManifestSemantics,
  type FeatureManifestV1,
} from './index'

const validateSchema = new Ajv({ allErrors: true }).compile(manifestSchema)

const validManifest = (): FeatureManifestV1 => ({
  manifestSchemaVersion: 1,
  sdkApiVersion: 1,
  id: 'store',
  version: '0.1.0',
  owner: 'agent-store-team',
  display: {
    titleKey: 'store:title',
    fallbackTitle: 'Store',
    iconKey: 'store',
  },
  targets: ['desktop'],
  requiredHostCapabilities: ['external-service:store'],
  contributions: {
    pages: [
      {
        id: 'home',
        path: '',
        surfaces: ['main'],
        navigation: { group: 'workspace', order: 100 },
      },
    ],
    settings: [],
    conversation: [],
    locales: ['en'],
  },
})

const schemaAccepts = (manifest: unknown) =>
  validateSchema(manifest) &&
  validateFeatureManifestSemantics(manifest as unknown as FeatureManifestV1)
    .length === 0

describe('Feature Manifest v1', () => {
  it('accepts the minimal valid manifest', () => {
    expect(schemaAccepts(validManifest())).toBe(true)
  })

  it('accepts a format-valid service capability without changing the schema', () => {
    expect(
      schemaAccepts({
        ...validManifest(),
        requiredHostCapabilities: ['service:knowledge-index'],
      })
    ).toBe(true)
  })

  it.each([
    ['unknown top-level field', { unexpected: true }],
    ['unsupported target', { targets: ['web'] }],
    ['empty targets', { targets: [] }],
    ['unknown capability', { requiredHostCapabilities: ['system:shell'] }],
  ])('rejects %s', (_label, patch) => {
    expect(validateSchema({ ...validManifest(), ...patch })).toBe(false)
  })

  it('rejects an unknown navigation group', () => {
    const manifest = validManifest()
    manifest.contributions.pages[0].navigation = {
      group: 'unknown' as 'workspace',
    }
    expect(validateSchema(manifest)).toBe(false)
  })

  it('rejects an invalid path and overlapping path ownership', () => {
    const invalidPath = validManifest()
    invalidPath.contributions.pages[0].path = '../admin'
    expect(schemaAccepts(invalidPath)).toBe(false)

    const overlap = validManifest()
    overlap.contributions.pages = [
      { id: 'root', path: 'agents', surfaces: ['main'] },
      { id: 'detail', path: 'agents/detail', surfaces: ['main'] },
    ]
    expect(schemaAccepts(overlap)).toBe(false)
  })

  it('requires English fallback text and paired descriptions', () => {
    const noFallback = validManifest()
    delete (noFallback.display as Partial<typeof noFallback.display>)
      .fallbackTitle
    expect(validateSchema(noFallback)).toBe(false)

    const unpairedDescription = validManifest()
    unpairedDescription.display.descriptionKey = 'store:description'
    expect(validateSchema(unpairedDescription)).toBe(false)
  })

  it('keeps closed schema enums synchronized with public constants', () => {
    const definitions = manifestSchema.$defs
    expect(definitions.hostCapability.anyOf[1].enum).toEqual(
      FEATURE_HOST_CAPABILITIES.filter(
        (capability) => !capability.startsWith('service:')
      )
    )
    expect(definitions.iconKey.enum).toEqual(FEATURE_ICON_KEYS)
    expect(definitions.pageNavigationGroup.enum).toEqual(
      FEATURE_PAGE_NAVIGATION_GROUPS
    )
    expect(definitions.settingsNavigationGroup.enum).toEqual(
      FEATURE_SETTINGS_NAVIGATION_GROUPS
    )
  })
})
