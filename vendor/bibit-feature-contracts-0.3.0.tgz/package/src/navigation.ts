export const FEATURE_PAGE_NAVIGATION_GROUPS = [
  'workspace',
  'library',
  'tools',
] as const

export const FEATURE_SETTINGS_NAVIGATION_GROUPS = [
  'core',
  'features',
  'integrations',
  'privacy',
] as const

export const FEATURE_ICON_KEYS = [
  'store',
  'memory',
  'security',
  'feature',
  'settings',
] as const

export type FeaturePageNavigationGroup =
  (typeof FEATURE_PAGE_NAVIGATION_GROUPS)[number]
export type FeatureSettingsNavigationGroup =
  (typeof FEATURE_SETTINGS_NAVIGATION_GROUPS)[number]
export type FeatureIconKey = (typeof FEATURE_ICON_KEYS)[number]

export interface FeaturePageNavigationV1 {
  group: FeaturePageNavigationGroup
  order?: number
}

export interface FeatureSettingsNavigationV1 {
  group: FeatureSettingsNavigationGroup
  order?: number
  titleKey?: string
  fallbackTitle?: string
  iconKey?: FeatureIconKey
  section?: FeatureSettingsNavigationSectionV1
}

export interface FeatureSettingsNavigationSectionV1 {
  id: string
  titleKey?: string
  fallbackTitle: string
}
