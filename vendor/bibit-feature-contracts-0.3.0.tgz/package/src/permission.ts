export type PermissionActionKindV1 = 'tool' | 'filesystem' | 'network' | 'system'

export interface PermissionActionV1 {
  kind: PermissionActionKindV1
  name: string
  summary: string
  details?: Readonly<Record<string, unknown>>
}

export interface PermissionIdentityV1 {
  runtimeInstanceId: string
  runtimeId: string
  runtimeEpoch: string
  sessionId: string
  threadId: string
  runId: string
  requestId: string
  toolCallId: string
}

export type PermissionDecisionKindV1 = 'allow_once' | 'deny'

export interface PermissionRequestV1 extends PermissionIdentityV1 {
  version: 1
  action: PermissionActionV1
  supportedDecisions: readonly PermissionDecisionKindV1[]
  createdAt: string
  expiresAt: string
}

export type PermissionDenyReasonV1 =
  | 'user-denied'
  | 'cancelled'
  | 'timed-out'
  | 'presenter-failed'
  | 'runtime-closed'

export type PermissionDecisionV1 = PermissionIdentityV1 &
  (
    | {
        version: 1
        decision: 'allow_once'
      }
    | {
        version: 1
        decision: 'deny'
        reason: PermissionDenyReasonV1
      }
  )

export type PermissionDecisionReceiptStatusV1 =
  | 'accepted'
  | 'duplicate'
  | 'stale'
  | 'expired'
  | 'rejected'

export interface PermissionDecisionReceiptV1 extends PermissionIdentityV1 {
  version: 1
  decision: PermissionDecisionKindV1
  status: PermissionDecisionReceiptStatusV1
}
