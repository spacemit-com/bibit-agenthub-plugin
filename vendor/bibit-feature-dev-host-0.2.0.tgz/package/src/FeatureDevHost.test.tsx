import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useEffect, useState } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { FeatureManifestV1 } from '@bibit/feature-contracts'
import { useFeatureCapability, type FeatureModuleV1 } from '@bibit/feature-sdk'
import { FeatureDevHost } from './FeatureDevHost'

const manifest: FeatureManifestV1 = {
  manifestSchemaVersion: 1,
  sdkApiVersion: 1,
  id: 'fixture',
  version: '0.1.0',
  owner: 'fixture-team',
  display: {
    titleKey: 'fixture:title',
    fallbackTitle: 'Fixture',
    iconKey: 'feature',
  },
  targets: ['desktop'],
  requiredHostCapabilities: [],
  contributions: {
    pages: [{ id: 'home', path: '', surfaces: ['main'] }],
    settings: [{ id: 'preferences', path: '', surfaces: ['main'] }],
    conversation: [],
    locales: ['en'],
  },
}

const module: FeatureModuleV1 = {
  sdkApiVersion: 1,
  pages: { home: () => <h2>Feature page</h2> },
  settings: { preferences: () => <h2>Feature settings</h2> },
}

describe('FeatureDevHost', () => {
  afterEach(() => vi.unstubAllGlobals())

  it('switches between declared contributions without Bibit', async () => {
    const user = userEvent.setup()
    render(<FeatureDevHost manifest={manifest} module={module} />)

    expect(screen.getByRole('heading', { name: 'Feature page' })).toBeTruthy()
    await user.click(screen.getByRole('button', { name: 'Settings · preferences' }))
    expect(screen.getByRole('heading', { name: 'Feature settings' })).toBeTruthy()
    expect(screen.getByText('SDK 1')).toBeTruthy()
  })

  it('connects a declared capability to a v1 external service endpoint', async () => {
    const connectedManifest: FeatureManifestV1 = {
      ...manifest,
      requiredHostCapabilities: ['external-service:store'],
      contributions: {
        ...manifest.contributions,
        settings: [],
      },
    }
    function ConnectedPage() {
      const store = useFeatureCapability('external-service:store')
      const [name, setName] = useState('Loading')
      useEffect(() => {
        void store
          ?.request<{ name: string }>({
            serviceId: 'store',
            operationId: 'agents.get.v1',
            params: { id: 'agent-1' },
          })
          .then((result) => setName(result.name))
      }, [store])
      return <h2>{name}</h2>
    }
    const connectedModule: FeatureModuleV1 = {
      sdkApiVersion: 1,
      pages: { home: ConnectedPage },
    }
    const fetchMock = vi.fn(async (_url: string, init: RequestInit) => {
      const request = JSON.parse(String(init.body))
      return {
        ok: true,
        json: async () => ({
          protocolVersion: 1,
          requestId: request.requestId,
          ok: true,
          result: { name: 'Connected agent' },
        }),
      }
    })
    vi.stubGlobal('fetch', fetchMock)

    render(
      <FeatureDevHost
        manifest={connectedManifest}
        module={connectedModule}
        serviceConnections={{ store: '/dev-services/store/invoke' }}
      />
    )

    expect(await screen.findByRole('heading', { name: 'Connected agent' })).toBeTruthy()
    expect(fetchMock).toHaveBeenCalledWith(
      '/dev-services/store/invoke',
      expect.objectContaining({ method: 'POST' })
    )
  })
})
