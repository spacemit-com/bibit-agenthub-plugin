// @vitest-environment node

import { createPublicKey, verify } from 'node:crypto'
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import * as tar from 'tar'
import {
  buildPluginBundle,
  generatePluginSigningKey,
} from './buildPlugin.js'

const temporaryDirectories: string[] = []

afterEach(async () => {
  await Promise.all(
    temporaryDirectories.splice(0).map((path) =>
      rm(path, { recursive: true, force: true })
    )
  )
})

describe('plugin bundle builder', () => {
  it('builds a signed, self-contained archive', async () => {
    const root = await createStyledPlugin('')
    await writeFile(
      join(root, 'src/plugin.ts'),
      'globalThis.__pluginMode = process.env.NODE_ENV\n'
    )
    const keys = await generatePluginSigningKey({
      outputDir: join(root, 'keys'),
      keyId: 'development',
    })
    const result = await buildPluginBundle({
      cwd: root,
      privateKeyPath: keys.privateKeyPath,
      keyId: 'development',
    })
    const unpacked = join(root, 'unpacked')
    await mkdir(unpacked)
    await tar.x({ cwd: unpacked, file: result.bundlePath })
    const manifestBytes = await readFile(join(unpacked, 'plugin.json'))
    const signature = JSON.parse(
      await readFile(join(unpacked, 'plugin.sig'), 'utf8')
    )
    const trustEntry = JSON.parse(await readFile(keys.trustEntryPath, 'utf8'))
    const trustStore = JSON.parse(await readFile(keys.trustStorePath, 'utf8'))
    expect(trustStore.keys).toEqual([trustEntry])
    const publicKey = createPublicKey({
      key: {
        kty: 'OKP',
        crv: 'Ed25519',
        x: Buffer.from(trustEntry.publicKey, 'base64').toString('base64url'),
      },
      format: 'jwk',
    })

    expect(
      verify(
        null,
        manifestBytes,
        publicKey,
        Buffer.from(signature.signature, 'base64')
      )
    ).toBe(true)
    const files = result.manifest.files as Record<string, string>
    expect(files['dist/plugin.js']).toMatch(/^[a-f0-9]{64}$/)
    const pluginSource = await readFile(join(unpacked, 'dist/plugin.js'), 'utf8')
    expect(pluginSource).toContain('production')
    expect(pluginSource).not.toContain('process.env.NODE_ENV')
  })

  it('accepts scoped plugin styles, including descendant universal selectors', async () => {
    const root = await createStyledPlugin(
      '.plugin, .plugin *, .plugin :is(*), :is(.plugin *) { box-sizing: border-box; }'
    )
    const keys = await generatePluginSigningKey({
      outputDir: join(root, 'keys'),
      keyId: 'development',
    })

    await expect(
      buildPluginBundle({
        cwd: root,
        privateKeyPath: keys.privateKeyPath,
        keyId: 'development',
      })
    ).resolves.toMatchObject({
      fileName: 'styled-plugin-0.1.0.bibit-plugin.tgz',
    })
  })

  it.each([
    [':root', ':root'],
    ['html', 'html'],
    ['body', 'body'],
    ['#root', '#root'],
    ['*', '*'],
    ['*::before', '*:before'],
    ['*::after', '*:after'],
    [':where(*)', ':where(*)'],
    [':is(*)', ':is(*)'],
    [':is(.plugin, *)', ':is(.plugin,*)'],
    [':where(.plugin, *)', ':where(.plugin,*)'],
    ['*:not(.plugin)', '*:not(.plugin)'],
    ['* + .plugin', '*+.plugin'],
  ])(
    'rejects the out-of-scope selector %s with the generated CSS file name',
    async (selector, builtSelector) => {
      const root = await createStyledPlugin(`${selector} { color: red; }`)
      const keys = await generatePluginSigningKey({
        outputDir: join(root, 'keys'),
        keyId: 'development',
      })

      await expect(
        buildPluginBundle({
          cwd: root,
          privateKeyPath: keys.privateKeyPath,
          keyId: 'development',
        })
      ).rejects.toThrow(
        `Plugin stylesheet dist/styled-plugin.css contains out-of-scope selector "${builtSelector}"`
      )
    }
  )

  it.each([
    ['@keyframes spin {}', '@keyframes', 'spin'],
    ['@-webkit-keyframes spin {}', '@-webkit-keyframes', 'spin'],
    [
      '@counter-style marker { system: cyclic; symbols: x; }',
      '@counter-style',
      'marker',
    ],
    [
      '@property --accent { syntax: "<color>"; inherits: false; initial-value: red; }',
      '@property',
      '--accent',
    ],
    [
      '@font-face { font-family: "Plugin Font"; src: local(Arial); }',
      '@font-face font-family',
      'Plugin Font',
    ],
  ])(
    'rejects the unprefixed global CSS name from %s',
    async (css, source, globalName) => {
      const root = await createStyledPlugin(css)
      const keys = await generatePluginSigningKey({
        outputDir: join(root, 'keys'),
        keyId: 'development',
      })

      await expect(
        buildPluginBundle({
          cwd: root,
          privateKeyPath: keys.privateKeyPath,
          keyId: 'development',
        })
      ).rejects.toThrow(
        `Plugin stylesheet dist/styled-plugin.css contains unprefixed global CSS name "${globalName}" in ${source}`
      )
    }
  )

  it('accepts feature-prefixed global CSS names', async () => {
    const root = await createStyledPlugin(`
      @keyframes styled-plugin-spin {}
      @-webkit-keyframes styled-plugin-pulse {}
      @counter-style styled-plugin-marker { system: cyclic; symbols: x; }
      @property --styled-plugin-accent { syntax: "<color>"; inherits: false; initial-value: red; }
      @font-face { font-family: "styled-plugin-font"; src: local(Arial); }
    `)
    const keys = await generatePluginSigningKey({
      outputDir: join(root, 'keys'),
      keyId: 'development',
    })

    await expect(
      buildPluginBundle({
        cwd: root,
        privateKeyPath: keys.privateKeyPath,
        keyId: 'development',
      })
    ).resolves.toMatchObject({
      fileName: 'styled-plugin-0.1.0.bibit-plugin.tgz',
    })
  })
})

async function createStyledPlugin(css: string) {
  const root = await mkdtemp(join(tmpdir(), 'bibit-styled-plugin-test-'))
  temporaryDirectories.push(root)
  await mkdir(join(root, 'src'))
  await writeFile(join(root, 'src/plugin.ts'), "import './plugin.css'\n")
  await writeFile(join(root, 'src/plugin.css'), css)
  await writeFile(
    join(root, 'bibit.feature.json'),
    JSON.stringify({
      manifestSchemaVersion: 1,
      sdkApiVersion: 1,
      id: 'styled-plugin',
      version: '0.1.0',
      owner: 'styled-plugin-team',
      display: {
        titleKey: 'styled-plugin:title',
        fallbackTitle: 'Styled plugin',
        iconKey: 'store',
      },
      targets: ['desktop'],
      requiredHostCapabilities: [],
      contributions: {
        pages: [],
        settings: [],
        conversation: [],
        locales: ['en'],
      },
    })
  )
  await writeFile(
    join(root, 'package.json'),
    JSON.stringify({
      name: '@example/styled-plugin',
      bibitPlugin: {
        entry: 'src/plugin.ts',
        manifest: 'bibit.feature.json',
      },
    })
  )
  return root
}
