import { act } from 'react'
import { describe, expect, it } from 'vitest'
import { useFeatureHostApi, type FeatureModuleV1 } from '@bibit/feature-sdk'
import type { FeatureHostApiV1 } from '@bibit/feature-sdk'
import type { FeatureManifestV1 } from '@bibit/feature-contracts'
import { registerFeaturePlugin } from './registerFeaturePlugin'

;(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean })
  .IS_REACT_ACT_ENVIRONMENT = true

const manifest: FeatureManifestV1 = {
  manifestSchemaVersion: 1,
  sdkApiVersion: 1,
  id: 'agent-hub',
  version: '0.1.0',
  owner: 'agent-hub-team',
  display: {
    titleKey: 'agent-hub:title',
    fallbackTitle: 'Agent Hub',
    iconKey: 'store',
  },
  targets: ['desktop'],
  requiredHostCapabilities: [],
  contributions: {
    pages: [
      { id: 'catalog', path: '', surfaces: ['main'] },
    ],
    settings: [],
    conversation: [],
    locales: ['en'],
  },
}

describe('registerFeaturePlugin', () => {
  it('mounts a Feature component in a stable custom element with Host API access', async () => {
    function Catalog({ contributionId }: { contributionId: string }) {
      return (
        <span>{`${useFeatureHostApi().featureId}:${contributionId}`}</span>
      )
    }
    const module = {
      sdkApiVersion: 1,
      pages: { catalog: Catalog },
    } satisfies FeatureModuleV1
    const hostApi: FeatureHostApiV1 = {
      sdkApiVersion: 1,
      featureId: 'agent-hub',
      grantedCapabilities: [],
      getCapability: () => undefined,
    }

    registerFeaturePlugin({ manifest, module })
    const element = document.createElement('bibit-agent-hub-page-catalog') as
      HTMLElement & {
        bibitContext: {
          props: Record<string, unknown>
          hostApi: FeatureHostApiV1
        }
      }
    element.bibitContext = { props: { contributionId: 'catalog' }, hostApi }

    await act(async () => document.body.append(element))

    expect(element.textContent).toBe('agent-hub:catalog')
    await act(async () => element.remove())
  })

  it('rejects a manifest contribution without a renderer', () => {
    expect(() =>
      registerFeaturePlugin({
        manifest,
        module: { sdkApiVersion: 1 },
      })
    ).toThrow('pages.catalog')
  })
})
