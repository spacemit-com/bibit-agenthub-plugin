import type { ReactNode } from 'react'
import type { FeatureIconKey } from '@bibit/feature-contracts'

export interface FeatureIconProps {
  className?: string
  width?: number | string
  height?: number | string
}

export type FeatureIcon = (props: FeatureIconProps) => ReactNode

const icon = (path: ReactNode): FeatureIcon => (props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true" {...props}>
    {path}
  </svg>
)

export const featureIconCatalog: Readonly<Record<FeatureIconKey, FeatureIcon>> = {
  store: icon(<><path d="M4 9h16l-1-5H5L4 9Z" /><path d="M6 9v11h12V9M9 20v-6h6v6" /></>),
  memory: icon(<><rect x="5" y="5" width="14" height="14" rx="2" /><path d="M9 9h6v6H9zM9 2v3m6-3v3M9 19v3m6-3v3" /></>),
  security: icon(<path d="M12 2 4 5v6c0 5 3.4 9 8 11 4.6-2 8-6 8-11V5l-8-3Z" />),
  feature: icon(<path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6 5.6 18.4" />),
  settings: icon(<><circle cx="12" cy="12" r="3" /><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M19 5l-2 2M7 17l-2 2" /></>),
}

export const getFeatureIcon = (key: FeatureIconKey): FeatureIcon =>
  featureIconCatalog[key] ?? featureIconCatalog.feature
