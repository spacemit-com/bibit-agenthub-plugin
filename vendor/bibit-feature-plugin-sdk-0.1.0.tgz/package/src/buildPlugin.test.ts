// @vitest-environment node

import { createPublicKey, verify } from 'node:crypto'
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import * as tar from 'tar'
import {
  buildPluginBundle,
  generatePluginSigningKey,
} from './buildPlugin.js'

const temporaryDirectories: string[] = []

afterEach(async () => {
  await Promise.all(
    temporaryDirectories.splice(0).map((path) =>
      rm(path, { recursive: true, force: true })
    )
  )
})

describe('plugin bundle builder', () => {
  it('builds a signed, self-contained archive', async () => {
    const root = await mkdtemp(join(tmpdir(), 'bibit-plugin-test-'))
    temporaryDirectories.push(root)
    await mkdir(join(root, 'src'))
    await writeFile(join(root, 'src/plugin.ts'), 'globalThis.__pluginLoaded = true\n')
    await writeFile(
      join(root, 'bibit.feature.json'),
      JSON.stringify({
        manifestSchemaVersion: 1,
        sdkApiVersion: 1,
        id: 'agent-hub',
        version: '0.1.0',
        owner: 'agent-hub-team',
        display: {
          titleKey: 'agent-hub:title',
          fallbackTitle: 'Agent Hub',
          iconKey: 'store',
        },
        targets: ['desktop'],
        requiredHostCapabilities: [],
        contributions: {
          pages: [],
          settings: [],
          conversation: [],
          locales: ['en'],
        },
      })
    )
    await writeFile(
      join(root, 'package.json'),
      JSON.stringify({
        name: '@example/agent-hub',
        bibitPlugin: {
          entry: 'src/plugin.ts',
          manifest: 'bibit.feature.json',
        },
      })
    )
    const keys = await generatePluginSigningKey({
      outputDir: join(root, 'keys'),
      keyId: 'development',
    })
    const result = await buildPluginBundle({
      cwd: root,
      privateKeyPath: keys.privateKeyPath,
      keyId: 'development',
    })
    const unpacked = join(root, 'unpacked')
    await mkdir(unpacked)
    await tar.x({ cwd: unpacked, file: result.bundlePath })
    const manifestBytes = await readFile(join(unpacked, 'plugin.json'))
    const signature = JSON.parse(
      await readFile(join(unpacked, 'plugin.sig'), 'utf8')
    )
    const trustEntry = JSON.parse(await readFile(keys.trustEntryPath, 'utf8'))
    const trustStore = JSON.parse(await readFile(keys.trustStorePath, 'utf8'))
    expect(trustStore.keys).toEqual([trustEntry])
    const publicKey = createPublicKey({
      key: {
        kty: 'OKP',
        crv: 'Ed25519',
        x: Buffer.from(trustEntry.publicKey, 'base64').toString('base64url'),
      },
      format: 'jwk',
    })

    expect(
      verify(
        null,
        manifestBytes,
        publicKey,
        Buffer.from(signature.signature, 'base64')
      )
    ).toBe(true)
    const files = result.manifest.files as Record<string, string>
    expect(files['dist/plugin.js']).toMatch(/^[a-f0-9]{64}$/)
  })
})
